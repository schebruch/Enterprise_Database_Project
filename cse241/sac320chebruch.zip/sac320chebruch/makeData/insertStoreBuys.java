import java.util.Scanner;
import java.sql.*;


public class insertStoreBuys
{

	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
        System.out.println("Enter username");
        String us = null;
        String pas = null;
        us = in.next();
        System.out.println("Enter password");
        pas = in.next();
        Connection con = null;
        Statement s = null;
        try
        {
            con=DriverManager.getConnection("jdbc:oracle:thin:@edgar0.cse.lehigh.edu:1521:cse241",us, pas);
            s=con.createStatement();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            con.close();
            s.close();
        }

        System.out.println("Connection success");
	}
}
